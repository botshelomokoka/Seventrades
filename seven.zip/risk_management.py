# ... (Import necessary modules)
from seven_bot import bought_prices, initial_portfolio_value

def check_stop_loss(symbol, bought_price, stop_loss_percentage=0.06):
    # ... (Same as before)

def check_take_profit(symbol, bought_price, take_profit_percentage=0.20):
    # ... (Same as before)

def check_overall_stop_loss():
    # ... (Same as before)
