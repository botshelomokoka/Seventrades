# ... (Import necessary modules)
from user import exchange
import talib
import pandas as pd
import numpy as np
from scipy import stats

def calculate_trade_amount(symbol, projections):
    # ... (Same as before)

def predict_trend(symbol):
    # ... (Same as before)

def get_total_portfolio_value_usdt():
    # ... (Same as before)
